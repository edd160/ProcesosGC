<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
 <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="crossorigin=""/>
    <!-- Make sure you put this AFTER Leaflet's CSS -->
 <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="crossorigin=""></script>

<title>MAPA</title> 
</head> 
<body>
<?php

error_reporting (E_ALL  ^  E_NOTICE  ^  E_DEPRECATED);
// 1.- IDENTIFICACION nombre de la base, del usuario, clave y servidor

$db_host="localhost";
$db_name="id19182118_geo_tsia_db";
$db_login="id19182118_geo_tsia_user";
$db_pswd="UIMQRoo@2023";

$conn = mysqli_connect($db_host,$db_login,$db_pswd,$db_name);
    if(!$conn)
    {
        echo "<h3>No se ha podido conectar PHP - MySQL, verifique sus datos.</h3><hr><br>";
    }
    else
    {
        echo "<h3> </h3><hr><br>";
    }

// 2.- CONEXION A LA BASE DE DATOS
mysqli_select_db($conn, $db_name) or die(mysql_error());

$data1 = "";

//--------------------------------------------PARQUES-------------------------------------------------------------

$sql = "SELECT * FROM parques";  
$resultado = mysqli_query($conn, $sql);
//echo $sql.'<br>';

if($resultado->num_rows>0){
$num_filas = $resultado->num_rows;
echo "Parques ".$num_filas."<br>";

$data1 = $data1."\n var parque = { 'type':'FeatureCollection', \n 'features': [ \n";
$i=1;
while ($fila=$resultado->fetch_assoc())
{   if($i < $num_filas){
    $data1 = $data1."{'type':'Feature',\n 'properties':{'nombre':'".$fila['nombre']."', 'direccion':'".$fila['direccion']."'}, \n'geometry':{ 'type':'Point', 'coordinates':[".$fila['longitud'].",".$fila['latitud']."] }},\n";
    $i++;
    }
    else{
     $data1 = $data1."{'type':'Feature',\n 'properties':{'nombre':'".$fila['nombre']."', 'direccion':'".$fila['direccion']."'}, \n'geometry':{ 'type':'Point', 'coordinates':[".$fila['longitud'].",".$fila['latitud']."] }}\n";   
    }

}
    $data1 = $data1.']};';

}

//--------------------------------------------MUSEOS-------------------------------------------------------------

$sql = "SELECT * FROM museos";  
$resultado = mysqli_query($conn, $sql);
//echo $sql.'<br>';

if($resultado->num_rows>0){
$num_filas = $resultado->num_rows;
echo "Parques ".$num_filas."<br>";

$data1 = $data1."\n var museo = { 'type':'FeatureCollection', \n 'features': [ \n";
$i=1;
while ($fila=$resultado->fetch_assoc())
{   if($i < $num_filas){
    $data1 = $data1."{'type':'Feature',\n 'properties':{'nombre':'".$fila['nombre']."', 'direccion':'".$fila['direccion']."'}, \n'geometry':{ 'type':'Point', 'coordinates':[".$fila['longitud'].",".$fila['latitud']."] }},\n";
    $i++;
    }
    else{
     $data1 = $data1."{'type':'Feature',\n 'properties':{'nombre':'".$fila['nombre']."', 'direccion':'".$fila['direccion']."'}, \n'geometry':{ 'type':'Point', 'coordinates':[".$fila['longitud'].",".$fila['latitud']."] }}\n";   
    }

}
    $data1 = $data1.']};';

}

$file = fopen("datos.js", "w");
fwrite($file, $data1);
fclose($file);



?>
<div id="map" style="width: 100%; height: 800px; margin:auto">
  
<script src="datos.js" type="text/javascript"></script>
<script>
var parques = L.layerGroup();
var museos = L.layerGroup();
    
    var map = L.map('map', {
        center: [19.4095071,-98.872341],
        zoom: 10,
        layers: [parques, museos]
    });
    var tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);
    
    var blueIcon = L.icon({
        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowSize: [41, 41]
    });
    var greenIcon = L.icon({
        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowSize: [41, 41]
    });
//--------------------------------------------PARQUES-----------------------------------------
    function onEachFeatureParques(feature, layer) {
        var popupContent = '<p>nombre = ' +
                feature.properties.nombre;

        if (feature.properties && feature.properties.popupContent) {
            popupContent += feature.properties.popupContent;
        }
         
        layer.bindPopup(popupContent).addTo(parques);
    }

    var parquesLayer = L.geoJSON([parque], {

        style: function (feature) {
            return feature.properties && feature.properties.style;
        },

        onEachFeature: onEachFeatureParques,

          pointToLayer: function (feature, latlng) {
                return L.marker(latlng, {
                radius: 8,
                fillColor: '#ff7800',
                color: '#000',
                weight: 1,
                opacity: 1,
                fillOpacity: 0.8,
                icon:greenIcon
            });

        }

        
    }).addTo(map);
  //--------------------------------------------MUSEOS-----------------------------------------
    function onEachFeatureMuseos(feature, layer) {
        var popupContent = '<p>nombre = ' +
                feature.properties.nombre;

        if (feature.properties && feature.properties.popupContent) {
            popupContent += feature.properties.popupContent;
        }
         
        layer.bindPopup(popupContent).addTo(museos);
    }

    var museosLayer = L.geoJSON([museo], {

        style: function (feature) {
            return feature.properties && feature.properties.style;
        },

        onEachFeature: onEachFeatureMuseos,

        pointToLayer: function (feature, latlng) {
                return L.marker(latlng, {
                radius: 8,
                fillColor: '#ff7800',
                color: '#000',
                weight: 1,
                opacity: 1,
                fillOpacity: 0.8,
                icon:blueIcon
            });

        }

    }).addTo(map);
  //---------------------------------------------------------
var overlays = {
        'Parques': parques, 
        'Museos': museos
    };
    
var layerControl = L.control.layers().addTo(map);

layerControl.addOverlay(parques, 'Parques');
layerControl.addOverlay(museos, 'Museos');


</script>
</div> <!-- AQUI TERMINA EL MAPA -->

</body> 
</html> 


