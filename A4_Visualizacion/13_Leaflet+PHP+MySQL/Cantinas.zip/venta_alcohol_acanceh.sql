-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Host: db5009683277.hosting-data.io
-- Generation Time: Feb 26, 2024 at 04:27 PM
-- Server version: 10.5.17-MariaDB-1:10.5.17+maria~deb10-log
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbs8208167`
--

-- --------------------------------------------------------

--
-- Table structure for table `venta_alcohol_acanceh`
--

CREATE TABLE `venta_alcohol_acanceh` (
  `name` varchar(30) CHARACTER SET utf8 NOT NULL,
  `latitud` double NOT NULL,
  `longitud` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `venta_alcohol_acanceh`
--

INSERT INTO `venta_alcohol_acanceh` (`name`, `latitud`, `longitud`) VALUES
('Modelorama', 20.81126, -89.45062),
('Tienda Six', 20.8110162, -89.4552809),
('LICORERIA CALLE21', 20.81284, -89.4506627),
('NP- MODELORAMA CRUCERITO', 20.8126938, -89.4505802),
('Modelorama', 20.8149151, -89.4608068),
('Tienda Six', 20.807153, -89.454114),
('SIX', 20.8142104, -89.4630044),
('Modelorama', 20.81891, -89.449756),
('Modelorama', 20.8116183, -89.4448549),
('Modelorama 25a la privada', 20.8078472, -89.4424223),
('Six la Santa Cruz', 20.8439524, -89.473953);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
