<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Leaflet CSS -->
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    
    <!-- Leaflet.markercluster  -->
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.css">
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.Default.css">

    <title>Venta alcohol</title>
</head>
<body>
    <!-- Esto podría ir en un CSS -->
    <div id="map" style="height: 90vh; width: 100vw; margin: auto;"></div>
    
    <!-- Leaflet y Leaflet.markercluster -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    <script src="https://unpkg.com/leaflet.markercluster@1.4.1/dist/leaflet.markercluster-src.js"></script>

    <!-- Esto podria ir en un JS -->

    <script>
        var map = L.map('map').setView([20.97365448087455, -89.62251929669944], 12);

        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);
    </script>

    <!-- Agregar ubicaciones al mapa -->
    <script>
        var markerGroup = L.markerClusterGroup();

        // Carga dinámica de los marcadores desde el archivo JSON
        fetch('alcohol.json')
            .then(response => response.json())
            .then(data => {
                L.geoJSON(data).addTo(markerGroup);
            })
            .catch(error => console.error('Error cargando el GeoJSON:', error));

        // Agregar el grupo de marcadores al mapa
        map.addLayer(markerGroup);
    </script>

    <?php
        // Conectarse a la base de datos
      

  $db_host="db5009683277.hosting-data.io";
$db_name="dbs8208167";
$db_login="dbu145439";
$db_pswd="#SuicidePrevention2022";
  
        $data = "";
        $conn = mysqli_connect($db_host, $db_login, $db_pswd, $db_name);
        if (!$conn) {
            die("Error de conexión: " . mysqli_connect_error());
        }

        // Consulta para obtener los datos
        //$sql = "SELECT `name`, `latitud`, `longitud` FROM `venta_alcohol_kanasin` GROUP BY `name`"; 
        $sql = "SELECT * FROM `venta_alcohol_uman` UNION 
SELECT * FROM venta_alcohol_kanasin UNION
SELECT * FROM venta_alcohol_hunucma UNION
SELECT * FROM venta_alcohol_acanceh";
        $resultado = mysqli_query($conn, $sql);

        // Crear el contenido que tiene en alcohol_ventas.json
        $data = [
            "type" => "FeatureCollection",
            "features" => []
        ];

        while ($fila = mysqli_fetch_assoc($resultado)) {
            $feature = [
                "type" => "Feature",
                "properties" => [],
                "geometry" => [
                    "type" => "Point",
                    "coordinates" => [
                        floatval($fila['longitud']),
                        floatval($fila['latitud'])
                    ]
                ]
            ];

            $data["features"][] = $feature;
        }

        // Crea el archivo JSON
        $file = fopen("alcohol.json", "w");
        fwrite($file, json_encode($data, JSON_PRETTY_PRINT));
        fclose($file);

        // Cierra la conexión
        mysqli_free_result($resultado);
        mysqli_close($conn);

        echo "Archivo alcohol.js generado con éxito.";
    ?>
</body>
</html>