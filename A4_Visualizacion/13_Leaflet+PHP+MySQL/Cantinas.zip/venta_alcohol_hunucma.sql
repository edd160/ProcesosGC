-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Host: db5009683277.hosting-data.io
-- Generation Time: Feb 26, 2024 at 04:27 PM
-- Server version: 10.5.17-MariaDB-1:10.5.17+maria~deb10-log
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbs8208167`
--

-- --------------------------------------------------------

--
-- Table structure for table `venta_alcohol_hunucma`
--

CREATE TABLE `venta_alcohol_hunucma` (
  `name` varchar(30) CHARACTER SET utf8 NOT NULL,
  `latitud` double NOT NULL,
  `longitud` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `venta_alcohol_hunucma`
--

INSERT INTO `venta_alcohol_hunucma` (`name`, `latitud`, `longitud`) VALUES
('name', 0, 0),
('Modelorama', 21.0150059, -89.8801417),
('Modelorama', 21.0169699, -89.8803931),
('Modelorama', 21.0128557, -89.8758614),
('Modelorama', 21.0213587, -89.8779392),
('Modelorama', 21.012825, -89.871059),
('Modelorama', 21.0100421, -89.8815395),
('Modelorama', 21.0202963, -89.8696656),
('Modelorama', 21.0079874, -89.8749443),
('Modelorama', 21.0186302, -89.8685153),
('Modelorama', 21.0170724, -89.8864555),
('Modelorama', 21.026401, -89.874141),
('Modelorama', 21.0259813, -89.8815902),
('Modelorama', 21.0088206, -89.8676082),
('Modelorama', 21.0043116, -89.883247),
('Modelorama', 21.006525, -89.8874945),
('Modelorama', 21.0078362, -89.8649701),
('Modelorama', 21.0286682, -89.884265),
('Modelorama', 21.02393, -89.8620016),
('Modelorama', 21.02444, -89.8921228),
('Modelorama', 21.0271427, -89.859335),
('NP- MODELORAMA REYNA', 21.016318, -89.8772303),
('Licoreria El Chato Ceballos II', 21.0163688, -89.8777149),
('Tienda Six', 21.0173237, -89.8775478),
('Modelorama', 21.0150059, -89.8801417),
('Modelorama', 21.0169699, -89.8803931),
('Modelorama', 21.0128557, -89.8758614),
('Modelorama', 21.0213587, -89.8779392),
('Modelorama', 21.012825, -89.871059),
('Modelorama', 21.0100421, -89.8815395),
('Modelorama', 21.0202963, -89.8696656),
('Modelorama', 21.0079874, -89.8749443),
('Modelorama', 21.0186302, -89.8685153),
('Modelorama', 21.0170724, -89.8864555),
('Modelorama', 21.026401, -89.874141),
('Modelorama', 21.0259813, -89.8815902),
('Modelorama', 21.0088206, -89.8676082),
('Modelorama', 21.0043116, -89.883247),
('Modelorama', 21.006525, -89.8874945),
('Modelorama', 21.0078362, -89.8649701),
('Modelorama', 21.0286682, -89.884265),
('Modelorama', 21.02393, -89.8620016),
('Modelorama', 21.02444, -89.8921228),
('Modelorama', 21.0271427, -89.859335),
('NP- MODELORAMA REYNA', 21.016318, -89.8772303),
('Licoreria El Chato Ceballos II', 21.0163688, -89.8777149),
('Tienda Six', 21.0173237, -89.8775478),
('MODELORAMA \"KALAKXAAN\"', 21.0183128, -89.8788314),
('Expendio El Ni?o De Atocha', 21.0172031, -89.8807691),
('Tienda Six', 21.0180515, -89.8722054),
('Tienda Six', 21.0145412, -89.8824316),
('Tienda Six', 21.0218096, -89.8753876),
('Tienda Six Girasol', 21.0118476, -89.8835657),
('Modelorama', 21.0169227, -89.8685517),
('La casa de las micheriks', 21.0214514, -89.8839268),
('Tienda Six', 21.005607, -89.8810419),
('Modelorama \"Lourdes\"', 21.011111, -89.8882613),
('Six', 21.0075868, -89.8863289),
('Tienda Six El Chino', 21.0052681, -89.8834319),
('Expendio cristina', 21.0281123, -89.874023),
('Tienda Six', 21.0225657, -89.8648344),
('Tienda Six', 21.0287462, -89.8717552),
('Expendio Los 3 Hermanos', 21.030173, -89.8767874),
('Agencia Mex', 21.0293499, -89.8860148),
('Six Zazil Ha', 21.0183683, -89.8606627),
('Agencia P.M. Pacifico', 21.0256413, -89.890454),
('Modelorama', 21.0205896, -89.860604),
('Modelorama', 21.0315378, -89.8710794),
('Expendio \"PEP\"', 21.0282205, -89.8917513),
('Cervefr?o Tetiz', 20.9683249, -89.9290067),
('MODELORAMA ARIANITA', 20.95881, -89.934036),
('Expendio Arianita', 20.9587302, -89.9340365);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
